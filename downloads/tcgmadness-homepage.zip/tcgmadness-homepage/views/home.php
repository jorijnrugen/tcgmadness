<?php
// The homepage is also available directly as a standalone HTML page.
readfile(dirname(__DIR__) . '/index.html');
