# Meegeleverde onderdelen

- **jQuery 3.7.1**: OpenJS Foundation en andere bijdragers, MIT-licentie. Zie `JQUERY-LICENSE.txt`.
- **Knewave** en **Caveat**: lokaal opgeslagen lettertypen. De SIL Open Font License staat per lettertype in `fonts/`.
- **Chillax**, logo's, conventiefoto's en de speurtocht-affiche: hergebruikt uit de bestaande TCG Madness-repository.
- **Personage**: de aangeleverde TCG Madness-illustratie, bewerkt voor de donkere achtergrond zoals gevraagd.
