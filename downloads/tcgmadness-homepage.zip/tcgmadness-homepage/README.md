# TCG Madness — werkende homepage

De definitieve homepage staat in **`index.html`**, met aparte CSS en JavaScript/jQuery. Alle benodigde lettertypen, illustraties, foto's en de video worden lokaal geladen. Er is geen buildproces of Node-runtime nodig om de pagina te gebruiken.

## Starten

Serveer de projectmap met een gewone statische webserver, bijvoorbeeld:

```sh
python3 -m http.server 8000
```

Open daarna het pad `/index.html` via deze server. Een webserver is aanbevolen voor de volledige videobediening en ondertitels; rechtstreeks openen via `file://` kan hiervoor door de browser worden beperkt.

In de bestaande PHP-website toont `views/home.php` dezelfde HTML-homepage. `index.php`, de router en de andere pagina's zijn niet gewijzigd. De losse HTML-versie heeft geen PHP nodig.

## Bestanden

| Bestand of map           | Inhoud                                                                             |
| ------------------------ | ---------------------------------------------------------------------------------- |
| `index.html`             | Alle homepage-inhoud en toegankelijke vensters                                     |
| `css/home.css`           | Donkere vormgeving, responsieve layouts en bedieningstoestanden                    |
| `js/home.js`             | Navigatie, galerij, vensters, video en tabbladen met jQuery                        |
| `js/vendor/jquery.js`    | Lokaal meegeleverde jQuery 3.7.1                                                   |
| `assets/home/`           | Personage, afgeronde SVG-vlekken, penseelstreek, lettertypen, video en ondertitels |
| `images/`                | Bestaande logo's, conventiefoto's en speurtocht-affiche                            |
| `fonts/Chillax-*.woff2`  | Bestaande lettertypen voor lopende tekst                                           |
| `tests/homepage.spec.js` | Functionele browser- en toegankelijkheidscontroles                                 |

De eerdere ontwerpen in `concept/` zijn alleen referentiemateriaal; de homepage is daar niet van afhankelijk. Het downloadpakket bevat alleen de homepage en benodigde bestanden, niet de eerdere ontwerpen of `node_modules`. De testbestanden zijn meegeleverd voor verder onderhoud.

## Wat werkt

- Responsieve, vastgezette navigatie met actieve sectie, mobiel menu, Escape, buitenklik en nette focusovergangen.
- Interne links met ruimte voor de navigatiebalk, terug-naar-bovenknop en een contextuele ticketbalk.
- Zes fotoposities met categoriefilters en automatisch bijgewerkte aantallen.
- Fotovenster met onderschrift, teller, vorige/volgende, pijltjestoetsen, Home/End, swipe, originele afbeelding en focusherstel.
- Laadindicatie en opnieuw proberen bij een ontbrekende foto; een trage afbeelding kan geen nieuwere selectie overschrijven.
- Videovenster met native bediening, starten na gebruikersactie, Nederlandse beeldbeschrijvende ondertitels, pauzeren bij sluiten/tabwissel en herstelbare foutmelding.
- Speurtocht- en wedstrijdvensters met de originele affiche en deelname-uitleg.
- Standhouders-tabbladen met toetsenbordbediening en native uitklapbare FAQ.
- Klikbare locatiekaart en routeknop naar Google Maps.
- Afgeschermde vensters, focusbegrenzing, scrollvergrendeling en ondersteuning voor verminderde beweging.
- Bruikbare links naar foto's, video, affiche en tickets als JavaScript of jQuery niet beschikbaar is.

De pagina bevat geen formulieren die inzendingen veinzen, geen analytics, geen trackingpixel en geen cookies. Andere bestaande pagina's, de ticketshop, socialmedia-accounts en Google Maps openen via hun echte URL's.

## Inhoud aanpassen

### Foto's

De galerij heeft zes posities en hergebruikt voorlopig de drie beschikbare conventiefoto's met verschillende uitsneden. Vervang per `.gallery-item`:

- `href` en `data-image`: het volledige fotobestand;
- `img src` en `alt`: thumbnail en beschrijving;
- `data-full-alt`: beschrijving van de volledige foto als de thumbnail een uitsnede toont;
- `data-caption`: onderschrift;
- `data-category`: `cards` of `people`.

De filters en fototeller lezen de HTML automatisch uit. Bij meer dan zes posities moet je ook de desktopmozaïek in `css/home.css` uitbreiden; de gefilterde weergave past zich automatisch aan.

### Video

`assets/home/sfeerimpressie.mp4` is de stille fotomontage van 12 seconden uit het ontwerp. Vervang deze door de echte aftermovie en pas ook het posterbeeld, de duur bij de videoknop, de beschrijving en `sfeerimpressie.nl.vtt` aan. De huidige ondertitelcues beschrijven de drie scènes; voor gesproken video zijn passende gesproken ondertitels nodig.

### Evenementen en tickets

Data, locatie, toegangstijden en bedragen staan leesbaar in `index.html`. De huidige inhoud is gebaseerd op de bestaande website: Vosselaar 5–6 december 2026, gratis t.e.m. 12 jaar, dagticket €5 online/€7 aan de inkom en VIP-dagticket €8 online/€10 aan de inkom.

Alle drie de ticketkeuzes verwijzen naar de bestaande Weeztix-shop. Er zijn geen ongedocumenteerde parameters voor automatische ticketselectie toegevoegd: de bezoeker kiest het ticket in de ticketshop. Controleer definitieve beschikbaarheid, eventuele kosten en voorwaarden in de shop vóór publicatie.

Standhouders zijn nog niet bekend; beide dagpanelen melden dit eerlijk. Vervang hun inhoud zodra de deelnemers beschikbaar zijn. De wedstrijd bevat geen verzonnen deadline of specifieke prijs.

### Kleuren, personage en caching

Kleuren staan als CSS-variabelen bovenaan `css/home.css`. De illustratie is `assets/home/mascot.webp`. De krabbels staan als herbruikbare SVG-symbolen in de HTML; afgeronde kleurvormen staan in `assets/home/cloud-*.svg`.

De bestaande hostingconfiguratie kan CSS en JavaScript lang cachen. Verhoog daarom bij nieuwe versies de `?v=1`-waarde van `home.css` en `home.js` in de HTML. Gebruik bij vervangen afbeeldingen bij voorkeur een nieuwe bestandsnaam.

### Optionele meting

Ticketacties versturen alleen een lokaal `tcg:ticket-click`-event met `detail.placement` en `detail.event`. Er wordt niets extern verzonden. Dit is een aanknopingspunt voor eventuele latere analytics. Een klik naar de ticketshop is geen bevestigde aankoop.

## Ontwikkelcontroles

Node is alleen nodig voor de ontwikkeltools. Installeer de vastgelegde dependencies en een testbrowser:

```sh
npm ci
npx playwright install chromium
npm test
npm run format:check
```

Bij gebruik van een reeds geïnstalleerde Chromium kun je `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH` instellen op die executable. In de gebruikte cloudomgeving is getest met:

```sh
PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH=/usr/bin/chromium npm test
```

De suite start zelf een tijdelijke statische server en test desktop en mobiele Chromium. De 32 controles dekken de gewone bediening, foutscenario's, gebruik zonder JavaScript en zonder native dialog-API, en geautomatiseerde WCAG A/AA-controles van pagina en fotovenster. Een automatische scan is geen volledige toegankelijkheidscertificering.

Er wordt geen echte aankoop uitgevoerd. Externe bestemmingen worden niet tijdens de tests bezocht. Het ontwerp is niet gepubliceerd.
