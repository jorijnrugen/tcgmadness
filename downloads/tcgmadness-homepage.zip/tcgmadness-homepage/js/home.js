/* TCG Madness homepage. jQuery is served locally; no third-party UI plugins are needed. */
(function ($) {
  "use strict";

  // If jQuery cannot load, the HTML links, images, FAQ and ticket shop still work.
  if (!$) return;

  $(function () {
    const root = document.documentElement;
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
    const desktop = window.matchMedia("(min-width: 981px)");
    const $header = $(".header");
    const $menu = $(".menu-toggle");
    const $nav = $("#navigation");
    const $dock = $(".ticket-dock");
    const $backToTop = $(".back-to-top");
    const hero = document.querySelector(".hero");
    const pricing = document.getElementById("tickets");
    const footer = document.querySelector(".footer");
    let framePending = false;
    let activeModal = null;
    let headerOffset = 120;

    function focusWithoutScroll(element) {
      if (!element) return;
      try {
        element.focus({ preventScroll: true });
      } catch (_) {
        element.focus();
      }
    }

    function isVisible(element) {
      return Boolean(
        element && element.isConnected && element.getClientRects().length,
      );
    }

    function plainClick(event) {
      return (
        !event.ctrlKey &&
        !event.metaKey &&
        !event.shiftKey &&
        !event.altKey &&
        (!event.button || event.button === 0)
      );
    }

    function focusSection(element) {
      const target = element.querySelector("h1, h2") || element;
      const needsTabIndex = !target.hasAttribute("tabindex");
      if (needsTabIndex) target.setAttribute("tabindex", "-1");
      focusWithoutScroll(target);
      if (needsTabIndex)
        $(target).one("blur", function () {
          target.removeAttribute("tabindex");
        });
    }

    // Navigation is a non-modal disclosure, with normal links and predictable focus.
    function closeMenu(restoreFocus) {
      $menu.attr({ "aria-expanded": "false", "aria-label": "Menu openen" });
      $nav.removeClass("open");
      if (restoreFocus) focusWithoutScroll($menu[0]);
    }

    function syncNavigation() {
      const focusWasInMenu = $nav[0].contains(document.activeElement);
      closeMenu(!desktop.matches && focusWasInMenu);
      headerOffset = Math.ceil($header[0].getBoundingClientRect().height) + 16;
      root.style.setProperty("--header-offset", headerOffset + "px");
      schedulePageUpdate();
    }

    $menu.on("click.home", function () {
      const open = $menu.attr("aria-expanded") !== "true";
      $menu.attr({
        "aria-expanded": String(open),
        "aria-label": open ? "Menu sluiten" : "Menu openen",
      });
      $nav.toggleClass("open", open);
      if (open) focusWithoutScroll($nav.find("a")[0]);
    });

    $nav.on("click.home", 'a[href^="#"]', function (event) {
      if (!plainClick(event)) return;
      closeMenu(false);
      const section = document.getElementById(this.hash.slice(1));
      if (section)
        window.requestAnimationFrame(function () {
          focusSection(section);
        });
    });

    $(document).on("pointerdown.home", function (event) {
      if (!$nav[0].contains(event.target) && !$menu[0].contains(event.target))
        closeMenu(false);
    });

    $(document).on("keydown.home", function (event) {
      if (event.key === "Escape" && $menu.attr("aria-expanded") === "true")
        closeMenu(true);
    });

    desktop.addEventListener("change", syncNavigation);
    if (window.ResizeObserver)
      new ResizeObserver(syncNavigation).observe($header[0]);

    // A single modal manager handles scroll locking, keyboard focus and backdrops.
    // Native <dialog> provides the top layer; the fallback keeps older browsers usable.
    const modalStates = new WeakMap();
    const $fallbackBackdrop = $(".dialog-backdrop");

    function modalFocusables(dialog) {
      return $(dialog)
        .find(
          'a[href], button:not([disabled]), video[controls], [tabindex]:not([tabindex="-1"])',
        )
        .filter(function () {
          return isVisible(this) && !this.closest("[hidden]");
        })
        .get();
    }

    function finishModal(dialog) {
      const state = modalStates.get(dialog);
      if (!state || state.finished) return;
      state.finished = true;
      $(dialog).trigger("home:closing");
      if (activeModal === dialog) {
        activeModal = null;
        root.classList.remove("has-modal");
      }
      if (state.inertElements) {
        state.inertElements.forEach(function (entry) {
          entry.element.inert = entry.previous;
        });
        $fallbackBackdrop.prop("hidden", true);
      }
      $(dialog).removeClass("dialog-fallback").removeAttr("aria-modal role");
      if (state.restoreFocus !== false && isVisible(state.opener))
        focusWithoutScroll(state.opener);
      schedulePageUpdate();
    }

    function closeModal(dialog, restoreFocus) {
      const state = modalStates.get(dialog);
      if (state && restoreFocus === false) state.restoreFocus = false;
      // Pause media synchronously, before the browser queues its close event.
      $(dialog)
        .find("video")
        .each(function () {
          this.pause();
        });
      if (typeof dialog.close === "function" && dialog.open) dialog.close();
      else dialog.removeAttribute("open");
      finishModal(dialog);
    }

    function openModal(dialog, opener) {
      if (!dialog || (activeModal === dialog && dialog.hasAttribute("open")))
        return;
      if (activeModal) closeModal(activeModal, false);
      closeMenu(false);
      modalStates.set(dialog, {
        opener: opener || document.activeElement,
        finished: false,
        restoreFocus: true,
      });
      activeModal = dialog;
      root.classList.add("has-modal");
      if (typeof dialog.showModal === "function") dialog.showModal();
      else {
        const state = modalStates.get(dialog);
        state.inertElements = [];
        Array.from(document.body.children).forEach(function (element) {
          if (
            element === dialog ||
            element === $fallbackBackdrop[0] ||
            /^(DIALOG|SCRIPT|NOSCRIPT)$/.test(element.tagName)
          )
            return;
          state.inertElements.push({
            element: element,
            previous: Boolean(element.inert),
          });
          element.inert = true;
        });
        $fallbackBackdrop.prop("hidden", false);
        $(dialog)
          .attr({ open: "", role: "dialog", "aria-modal": "true" })
          .addClass("dialog-fallback");
      }
      dialog.scrollTop = 0;
      $dock.prop("hidden", true);
      focusWithoutScroll(
        dialog.querySelector("[data-dialog-close]") ||
          modalFocusables(dialog)[0],
      );
      $(dialog).trigger("home:opened");
    }

    $("dialog").each(function () {
      const dialog = this;
      let backdropPress = false;

      function outside(event) {
        const box = dialog.getBoundingClientRect();
        return (
          event.clientX < box.left ||
          event.clientX > box.right ||
          event.clientY < box.top ||
          event.clientY > box.bottom
        );
      }

      $(dialog).on("pointerdown.home", function (event) {
        backdropPress =
          event.target === dialog && outside(event.originalEvent || event);
      });
      $(dialog).on("click.home", function (event) {
        if (
          backdropPress &&
          event.target === dialog &&
          outside(event.originalEvent || event)
        )
          closeModal(dialog);
        backdropPress = false;
      });
      $(dialog).on("cancel.home", function (event) {
        event.preventDefault();
        closeModal(dialog);
      });
      $(dialog).on("close.home", function () {
        // A queued close event must not clean up a dialog that was reopened.
        if (!dialog.hasAttribute("open")) finishModal(dialog);
      });
      $(dialog).on("click.home", "[data-dialog-close]", function () {
        closeModal(dialog);
      });
      $(dialog).on("keydown.home", function (event) {
        if (event.key === "Escape") {
          event.preventDefault();
          event.stopPropagation();
          closeModal(dialog);
          return;
        }
        if (event.key !== "Tab") return;
        const controls = modalFocusables(dialog);
        if (!controls.length) {
          event.preventDefault();
          return;
        }
        const first = controls[0];
        const last = controls[controls.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          focusWithoutScroll(last);
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          focusWithoutScroll(first);
        }
      });
    });

    $fallbackBackdrop.on("click.home", function () {
      if (activeModal) closeModal(activeModal);
    });
    $(document).on("focusin.home", function (event) {
      if (activeModal && !activeModal.contains(event.target)) {
        focusWithoutScroll(modalFocusables(activeModal)[0]);
      }
    });

    // Gallery: filtered scope, captions, loading/error states, keyboard and touch.
    const $gallery = $("#gallery-grid");
    const $photos = $gallery.find(".gallery-item");
    const $filters = $("[data-filter]");
    const galleryDialog = document.getElementById("gallery-dialog");
    const $imageViewport = $(galleryDialog).find(".lightbox-image");
    const $largePhoto = $("#lightbox-photo");
    const $photoLoading = $(galleryDialog).find(".photo-loading");
    const $photoError = $(galleryDialog).find(".photo-error");
    const $original = $("#photo-original");
    let selectedPhoto = 0;
    let photoGeneration = 0;
    let swipeStart = null;

    function visiblePhotos() {
      return $photos
        .filter(function () {
          return !this.hidden;
        })
        .get();
    }

    function warmPhoto(url) {
      if (navigator.connection && navigator.connection.saveData) return;
      const image = new Image();
      image.src = url;
    }

    function displayPhoto() {
      const photos = visiblePhotos();
      if (!photos.length) return;
      selectedPhoto =
        ((selectedPhoto % photos.length) + photos.length) % photos.length;
      const item = photos[selectedPhoto];
      const url = $(item).attr("data-image") || item.href;
      const description =
        $(item).attr("data-full-alt") ||
        $(item).find("img").attr("alt") ||
        "Foto van TCG Madness";
      const generation = ++photoGeneration;
      const thumbnail = item.querySelector("img");
      if (thumbnail.naturalWidth && thumbnail.naturalHeight) {
        $imageViewport.css(
          "--photo-aspect",
          thumbnail.naturalWidth + " / " + thumbnail.naturalHeight,
        );
      }
      $("#gallery-caption").text($(item).attr("data-caption") || description);
      $("#lightbox-counter").text(
        "Foto " + (selectedPhoto + 1) + " van " + photos.length,
      );
      $original.attr("href", url).prop("hidden", false);
      $imageViewport.attr("aria-busy", "true").removeClass("has-photo-error");
      $largePhoto.css("visibility", "hidden");
      $photoLoading.prop("hidden", false);
      $photoError.prop("hidden", true);
      $(galleryDialog)
        .find(".gallery-prev, .gallery-next")
        .prop("disabled", photos.length < 2);

      const image = new Image();
      image.decoding = "async";
      image.onload = function () {
        if (generation !== photoGeneration) return;
        $imageViewport.css(
          "--photo-aspect",
          image.naturalWidth + " / " + image.naturalHeight,
        );
        $largePhoto
          .attr({ src: url, alt: description })
          .css("visibility", "visible");
        $imageViewport.attr("aria-busy", "false");
        $photoLoading.prop("hidden", true);
        if (photos.length > 1) {
          warmPhoto(
            $(photos[(selectedPhoto + 1) % photos.length]).attr("data-image"),
          );
          warmPhoto(
            $(photos[(selectedPhoto - 1 + photos.length) % photos.length]).attr(
              "data-image",
            ),
          );
        }
      };
      image.onerror = function () {
        if (generation !== photoGeneration) return;
        $imageViewport.attr("aria-busy", "false").addClass("has-photo-error");
        $photoLoading.prop("hidden", true);
        $photoError.prop("hidden", false);
        $original.prop("hidden", true);
      };
      image.src = url;
    }

    function movePhoto(direction) {
      selectedPhoto += direction;
      displayPhoto();
    }

    $filters.on("click.home", function () {
      const filter = $(this).attr("data-filter");
      $filters.attr("aria-pressed", "false");
      $(this).attr("aria-pressed", "true");
      $photos.each(function () {
        this.hidden =
          filter !== "all" && $(this).attr("data-category") !== filter;
      });
      $gallery.toggleClass("is-filtered", filter !== "all");
      const count = visiblePhotos().length;
      $("#gallery-count").text(count === 1 ? "1 foto" : count + " foto’s");
      selectedPhoto = 0;
      schedulePageUpdate();
    });

    $photos.on("click.home", function (event) {
      if (!plainClick(event)) return;
      event.preventDefault();
      selectedPhoto = visiblePhotos().indexOf(this);
      displayPhoto();
      openModal(galleryDialog, this);
    });
    $(galleryDialog).on("click.home", ".gallery-prev", function () {
      movePhoto(-1);
    });
    $(galleryDialog).on("click.home", ".gallery-next", function () {
      movePhoto(1);
    });
    $(galleryDialog).on("click.home", "[data-photo-retry]", displayPhoto);
    $(galleryDialog).on("keydown.home", function (event) {
      if (
        event.altKey ||
        event.ctrlKey ||
        event.metaKey ||
        event.target.closest("input, textarea, select")
      )
        return;
      if (event.key === "ArrowRight") {
        event.preventDefault();
        movePhoto(1);
      }
      if (event.key === "ArrowLeft") {
        event.preventDefault();
        movePhoto(-1);
      }
      if (event.key === "Home") {
        event.preventDefault();
        selectedPhoto = 0;
        displayPhoto();
      }
      if (event.key === "End") {
        event.preventDefault();
        selectedPhoto = visiblePhotos().length - 1;
        displayPhoto();
      }
    });
    $(galleryDialog).on("home:closing", function () {
      ++photoGeneration;
      swipeStart = null;
      $photoLoading.prop("hidden", true);
      $imageViewport.attr("aria-busy", "false");
    });
    $imageViewport.on("pointerdown.home", function (event) {
      const pointer = event.originalEvent;
      if (
        pointer.pointerType !== "touch" ||
        !pointer.isPrimary ||
        event.target.closest("button")
      ) {
        swipeStart = null;
        return;
      }
      swipeStart = {
        x: pointer.clientX,
        y: pointer.clientY,
        id: pointer.pointerId,
      };
    });
    $imageViewport.on("pointerup.home", function (event) {
      const pointer = event.originalEvent;
      if (!swipeStart || pointer.pointerId !== swipeStart.id) return;
      const dx = pointer.clientX - swipeStart.x;
      const dy = pointer.clientY - swipeStart.y;
      swipeStart = null;
      if (Math.abs(dx) >= 48 && Math.abs(dx) > Math.abs(dy) * 1.4)
        movePhoto(dx < 0 ? 1 : -1);
    });
    $imageViewport.on("pointercancel.home", function () {
      swipeStart = null;
    });
    $("[data-gallery-total]").text(String($photos.length).padStart(2, "0"));
    $("#gallery-count").text($photos.length + " foto’s");

    // User-initiated playback. The MP4 is not fetched until the visitor opens it.
    const videoDialog = document.getElementById("film-dialog");
    const video = document.getElementById("convention-video");
    const $videoFeedback = $(videoDialog).find(".video-feedback");
    let videoAttempt = 0;

    function videoError() {
      $videoFeedback
        .prop("hidden", false)
        .find(".video-feedback-text")
        .text(
          "De video kan niet worden geladen. Probeer opnieuw of open het videobestand rechtstreeks.",
        );
    }

    function startVideo(retry) {
      const attempt = ++videoAttempt;
      $videoFeedback.prop("hidden", true);
      if (retry || video.error || video.networkState === 3) video.load();
      if (video.ended) video.currentTime = 0;
      try {
        const playback = video.play();
        if (playback && playback.catch)
          playback.catch(function (error) {
            if (attempt !== videoAttempt || !videoDialog.open) return;
            if (
              video.error ||
              (error.name !== "NotAllowedError" && error.name !== "AbortError")
            )
              videoError();
            // If autoplay is declined, the native play control remains available.
          });
      } catch (_) {
        if (video.error) videoError();
      }
    }

    $("[data-open-video]").on("click.home", function (event) {
      if (!plainClick(event)) return;
      event.preventDefault();
      openModal(videoDialog, this);
      startVideo(false);
    });
    $(video).find("source").on("error.home", videoError);
    $(video)
      .on("error.home", videoError)
      .on("playing.home", function () {
        $videoFeedback.prop("hidden", true);
      });
    $(videoDialog).on("click.home", "[data-video-retry]", function () {
      startVideo(true);
    });
    $(videoDialog).on("home:closing", function () {
      ++videoAttempt;
      video.pause();
    });
    $(document).on("visibilitychange.home", function () {
      if (document.hidden) video.pause();
    });

    // Activity rules use the supplied campaign; the two panels share one modal.
    const activityDialog = document.getElementById("activity-dialog");
    $("[data-open-activity]").on("click.home", function (event) {
      if (!plainClick(event)) return;
      event.preventDefault();
      const hunt = $(this).attr("data-open-activity") === "hunt";
      $("#hunt-details").prop("hidden", !hunt);
      $("#dress-details").prop("hidden", hunt);
      $("#activity-dialog-title").text(
        hunt ? "Speurneus aan. Op avontuur!" : "Jouw outfit in de spotlights.",
      );
      $("#activity-dialog-kicker").text(
        hunt ? "DE TCG MADNESS-SPEURTOCHT" : "DE VERKLEEDWEDSTRIJD",
      );
      openModal(activityDialog, this);
    });

    // Exhibitor tabs support arrows and Home/End as well as pointer navigation.
    $("[role=tablist]").each(function () {
      const $tabs = $(this).find("[role=tab]");
      function selectTab(tab) {
        $tabs.each(function () {
          const selected = this === tab;
          $(this).attr({
            "aria-selected": String(selected),
            tabindex: selected ? "0" : "-1",
          });
          $("#" + $(this).attr("aria-controls")).prop("hidden", !selected);
        });
      }
      $tabs.on("click.home", function () {
        selectTab(this);
      });
      $tabs.on("keydown.home", function (event) {
        const index = $tabs.index(this);
        let next = null;
        if (event.key === "ArrowRight")
          next = $tabs[(index + 1) % $tabs.length];
        if (event.key === "ArrowLeft")
          next = $tabs[(index - 1 + $tabs.length) % $tabs.length];
        if (event.key === "Home") next = $tabs[0];
        if (event.key === "End") next = $tabs[$tabs.length - 1];
        if (next) {
          event.preventDefault();
          selectTab(next);
          focusWithoutScroll(next);
        }
      });
      selectTab($tabs.filter('[aria-selected="true"]')[0] || $tabs[0]);
    });

    // One requestAnimationFrame pass handles scroll-related UI without a busy loop.
    const navItems = $nav
      .find('a[href^="#"]')
      .get()
      .map(function (link) {
        return {
          link: link,
          section: document.getElementById(link.hash.slice(1)),
        };
      })
      .filter(function (entry) {
        return entry.section;
      });

    function updatePage() {
      framePending = false;
      const y = window.scrollY;
      $header.toggleClass("is-scrolled", y > 24);
      const tickets = pricing.getBoundingClientRect();
      const heroPassed = hero.getBoundingClientRect().bottom <= headerOffset;
      const pricesVisible =
        tickets.top < window.innerHeight && tickets.bottom > headerOffset;
      const footerVisible =
        footer.getBoundingClientRect().top < window.innerHeight - 24;
      $dock.prop(
        "hidden",
        !heroPassed || pricesVisible || footerVisible || Boolean(activeModal),
      );
      $backToTop.prop("hidden", y < 800 || Boolean(activeModal));
      let closest = navItems[0];
      let closestTop = -Infinity;
      navItems.forEach(function (entry) {
        const top = entry.section.getBoundingClientRect().top;
        if (top <= headerOffset + 100 && top > closestTop) {
          closest = entry;
          closestTop = top;
        }
      });
      navItems.forEach(function (entry) {
        if (entry === closest)
          entry.link.setAttribute("aria-current", "location");
        else entry.link.removeAttribute("aria-current");
      });
    }

    function schedulePageUpdate() {
      if (framePending) return;
      framePending = true;
      window.requestAnimationFrame(updatePage);
    }

    window.addEventListener("scroll", schedulePageUpdate, { passive: true });
    window.addEventListener("resize", schedulePageUpdate, { passive: true });
    $(window).on("hashchange.home", schedulePageUpdate);
    $backToTop.on("click.home", function (event) {
      if (!plainClick(event)) return;
      event.preventDefault();
      window.scrollTo({
        top: 0,
        behavior: reduceMotion.matches ? "instant" : "smooth",
      });
      // Do not add repeated #top entries to the browser history.
      if (window.location.hash)
        history.replaceState(
          null,
          "",
          window.location.pathname + window.location.search,
        );
      focusWithoutScroll(document.querySelector(".logo"));
    });

    $("[data-current-year]").text(new Date().getFullYear());
    $(document).on("click.home", "[data-ticket-placement]", function () {
      // An optional integration hook, not a tracker. No data leaves this page.
      document.dispatchEvent(
        new CustomEvent("tcg:ticket-click", {
          detail: {
            placement: $(this).attr("data-ticket-placement"),
            event: "vosselaar-2026",
          },
        }),
      );
    });

    root.classList.remove("no-js");
    root.classList.add("is-enhanced");
    syncNavigation();
    schedulePageUpdate();
  });
})(window.jQuery);
