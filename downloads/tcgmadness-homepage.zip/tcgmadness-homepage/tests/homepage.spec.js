const { test, expect } = require("@playwright/test");
const AxeBuilder = require("@axe-core/playwright").default;

const home = "/index.html";
const checkout =
  "https://shop.weeztix.com/a8e90616-11cd-4608-9719-146cf10634ad";

async function goToSection(page, id) {
  await page.evaluate(
    (id) =>
      document
        .getElementById(id)
        .scrollIntoView({ behavior: "instant", block: "start" }),
    id,
  );
}

async function openPhoto(page) {
  await goToSection(page, "galerij");
  await page.locator(".gallery-item").first().click();
  await expect(page.locator("#gallery-dialog")).toBeVisible();
  await expect(page.locator(".lightbox-image")).toHaveAttribute(
    "aria-busy",
    "false",
  );
}

test.use({ reducedMotion: "reduce" });
test.beforeEach(async ({ page }) => {
  await page.goto(home);
  await expect(page.locator("html")).toHaveClass(/is-enhanced/);
});

test("zelfstandige pagina, lokale assets en werkende jQuery", async ({
  page,
}) => {
  const errors = [];
  const failed = [];
  const external = [];
  page.on("pageerror", (error) => errors.push(error.message));
  page.on("response", (response) => {
    if (response.status() >= 400) failed.push(response.url());
  });
  page.on("request", (request) => {
    if (
      request.url().startsWith("http") &&
      !request.url().startsWith("http://127.0.0.1:4173/")
    )
      external.push(request.url());
  });
  await page.reload();
  await expect(page.locator("html")).toHaveClass(/is-enhanced/);
  expect(await page.evaluate(() => window.jQuery.fn.jquery)).toBe("3.7.1");
  await expect(page).toHaveTitle(/TCG Madness.*Vosselaar/);
  await expect(page.locator("h1")).toContainText("MADNESS");
  await page.locator('img[loading="lazy"]').evaluateAll((images) =>
    images.forEach((image) => {
      image.loading = "eager";
    }),
  );
  await page.evaluate(() =>
    Promise.all(
      [...document.images].map((image) => image.decode().catch(() => {})),
    ),
  );
  const broken = await page
    .locator("img")
    .evaluateAll((images) =>
      images
        .filter((image) => !image.complete || !image.naturalWidth)
        .map((image) => image.src),
    );
  expect(broken).toEqual([]);
  const missingAnchors = await page
    .locator('a[href^="#"]')
    .evaluateAll((links) =>
      links
        .filter(
          (link) => link.hash && !document.getElementById(link.hash.slice(1)),
        )
        .map((link) => link.hash),
    );
  expect(missingAnchors).toEqual([]);
  await expect(page.locator("a.map-art")).toHaveAttribute(
    "href",
    await page
      .locator(".location-grid > div > .text-link")
      .getAttribute("href"),
  );
  expect(errors).toEqual([]);
  expect(failed).toEqual([]);
  expect(external).toEqual([]);
});

test("ticketkeuzes sturen naar de bestaande checkout zonder verzonnen selectie", async ({
  page,
}) => {
  await expect(page.locator(".ticket-card")).toHaveCount(3);
  for (const placement of ["kids", "day", "vip"]) {
    const link = page.locator(`[data-ticket-placement="${placement}"]`);
    await expect(link).toHaveAttribute("href", checkout);
    await expect(link).toHaveAttribute("target", "_blank");
    await expect(link).toHaveAttribute("rel", /noopener/);
  }
  await expect(
    page.locator(".ticket-card").nth(0).locator(".price"),
  ).toHaveText("Gratis");
  await expect(
    page.locator(".ticket-card").nth(1).locator(".price"),
  ).toContainText("€5");
  await expect(
    page.locator(".ticket-card").nth(2).locator(".price"),
  ).toContainText("€8");
  const hook = page.evaluate(
    () =>
      new Promise((resolve) =>
        document.addEventListener(
          "tcg:ticket-click",
          (event) => resolve(event.detail),
          { once: true },
        ),
      ),
  );
  await page.locator('[data-ticket-placement="hero"]').click();
  expect(await hook).toEqual({ placement: "hero", event: "vosselaar-2026" });
  await expect(page).toHaveURL(/#tickets$/);
  await expect(page.locator("#tickets")).toBeInViewport();
});

test("desktop- en mobiele navigatie, ankers en Escape", async ({ page }) => {
  const mobileNavigation = page.viewportSize().width <= 980;
  if (mobileNavigation) {
    await expect(page.locator("#navigation")).not.toBeVisible();
    await page.locator(".menu-toggle").click();
    await expect(page.locator(".menu-toggle")).toHaveAttribute(
      "aria-expanded",
      "true",
    );
    await expect(page.locator("#navigation a").first()).toBeFocused();
    await page.keyboard.press("Escape");
    await expect(page.locator(".menu-toggle")).toBeFocused();
    await expect(page.locator("#navigation")).not.toBeVisible();
    await page.locator(".menu-toggle").click();
    const menuBox = await page.locator("#navigation").boundingBox();
    await page.mouse.click(5, menuBox.y + menuBox.height + 15);
    await expect(page.locator("#navigation")).not.toBeVisible();
    await page.locator(".menu-toggle").click();
  } else {
    await expect(page.locator("#navigation")).toBeVisible();
    await expect(page.locator(".menu-toggle")).not.toBeVisible();
  }
  await page.locator('#navigation a[href="#activiteiten"]').click();
  await expect(page).toHaveURL(/#activiteiten$/);
  await expect(page.locator("#activiteiten h2")).toBeFocused();
  await expect(
    page.locator('#navigation a[href="#activiteiten"]'),
  ).toHaveAttribute("aria-current", "location");
  const top = await page
    .locator("#activiteiten")
    .evaluate((element) => element.getBoundingClientRect().top);
  const headerBottom = await page
    .locator(".header")
    .evaluate((element) => element.getBoundingClientRect().bottom);
  expect(top).toBeGreaterThanOrEqual(headerBottom - 2);
  if (mobileNavigation)
    await expect(page.locator("#navigation")).not.toBeVisible();
});

test("galerijfilters en fotovenster met toetsenbord en focusherstel", async ({
  page,
}) => {
  await goToSection(page, "galerij");
  await expect(page.locator(".gallery-item:visible")).toHaveCount(6);
  await page.locator('[data-filter="cards"]').click();
  await expect(page.locator(".gallery-item:visible")).toHaveCount(3);
  await expect(page.locator("#gallery-count")).toHaveText("3 foto’s");
  await page.locator(".gallery-item:visible").first().click();
  await expect(page.locator("#lightbox-counter")).toHaveText("Foto 1 van 3");
  await expect(page.locator(".lightbox-image")).toHaveAttribute(
    "aria-busy",
    "false",
  );
  const photoSize = await page.locator("#lightbox-photo").evaluate((image) => ({
    width: image.getBoundingClientRect().width,
    height: image.getBoundingClientRect().height,
    naturalWidth: image.naturalWidth,
    naturalHeight: image.naturalHeight,
    viewportHeight: innerHeight,
  }));
  expect(
    Math.abs(
      photoSize.height -
        Math.min(
          (photoSize.width * photoSize.naturalHeight) / photoSize.naturalWidth,
          photoSize.viewportHeight * 0.6,
          650,
        ),
    ),
  ).toBeLessThan(3);
  await expect(page.locator(".close-gallery")).toBeFocused();
  await page.keyboard.press("Shift+Tab");
  await expect(page.locator("#photo-original")).toBeFocused();
  await page.keyboard.press("Tab");
  await expect(page.locator(".close-gallery")).toBeFocused();
  await page.keyboard.press("ArrowLeft");
  await expect(page.locator("#lightbox-counter")).toHaveText("Foto 3 van 3");
  await page.keyboard.press("Home");
  await expect(page.locator("#lightbox-counter")).toHaveText("Foto 1 van 3");
  await page.locator(".gallery-next").click();
  await expect(page.locator("#lightbox-counter")).toHaveText("Foto 2 van 3");
  await page.keyboard.press("End");
  await expect(page.locator("#lightbox-counter")).toHaveText("Foto 3 van 3");
  await page.keyboard.press("Escape");
  await expect(page.locator("#gallery-dialog")).not.toBeVisible();
  await expect(page.locator(".gallery-item:visible").first()).toBeFocused();
  await page.locator('[data-filter="people"]').click();
  await expect(page.locator(".gallery-item:visible")).toHaveCount(3);
  await page.locator('[data-filter="all"]').click();
  await expect(page.locator(".gallery-item:visible")).toHaveCount(6);
});

test("galerij reageert op swipe en sluit alleen op een echte backdropklik", async ({
  page,
}) => {
  await openPhoto(page);
  const viewport = page.locator(".lightbox-image");
  await viewport.dispatchEvent("pointerdown", {
    pointerType: "touch",
    pointerId: 1,
    isPrimary: true,
    clientX: 270,
    clientY: 200,
  });
  await viewport.dispatchEvent("pointerup", {
    pointerType: "touch",
    pointerId: 1,
    isPrimary: true,
    clientX: 150,
    clientY: 204,
  });
  await expect(page.locator("#lightbox-counter")).toHaveText("Foto 2 van 6");
  // An ordinary click on the image is not a backdrop dismissal.
  await page.locator("#lightbox-photo").click();
  await expect(page.locator("#gallery-dialog")).toBeVisible();
  await page.mouse.click(2, 2);
  await expect(page.locator("#gallery-dialog")).not.toBeVisible();
});

test("een ontbrekende foto geeft herstelbare feedback", async ({ page }) => {
  const item = page.locator(".gallery-item").first();
  const original = await item.getAttribute("data-image");
  await item.evaluate((element) => {
    element.dataset.image = "images/missing-photo-test.jpg";
  });
  await openPhoto(page);
  await expect(page.locator(".photo-error")).toBeVisible();
  await expect(page.locator("#photo-original")).not.toBeVisible();
  await item.evaluate((element, source) => {
    element.dataset.image = source;
  }, original);
  await page.locator("[data-photo-retry]").click();
  await expect(page.locator(".photo-error")).not.toBeVisible();
  await expect(page.locator("#lightbox-photo")).toHaveAttribute(
    "src",
    original,
  );
  await expect(page.locator(".lightbox-image")).toHaveAttribute(
    "aria-busy",
    "false",
  );
});

test("een trage foto overschrijft geen nieuwere fotokeuze", async ({
  page,
}) => {
  const item = page.locator(".gallery-item").first();
  const original = await item.getAttribute("data-image");
  await page.route("**/*slow-photo*", async (route) => {
    const response = await route.fetch();
    await new Promise((resolve) => setTimeout(resolve, 350));
    await route.fulfill({ response });
  });
  await item.evaluate((element, source) => {
    element.dataset.image = source + "?slow-photo=1";
  }, original);
  await goToSection(page, "galerij");
  await item.click();
  await page.locator(".gallery-next").click();
  await expect(page.locator("#lightbox-counter")).toHaveText("Foto 2 van 6");
  await expect(page.locator(".lightbox-image")).toHaveAttribute(
    "aria-busy",
    "false",
  );
  const second = await page
    .locator(".gallery-item")
    .nth(1)
    .getAttribute("data-image");
  await expect(page.locator("#lightbox-photo")).toHaveAttribute("src", second);
  await page.waitForTimeout(450);
  await expect(page.locator("#lightbox-photo")).toHaveAttribute("src", second);
});

test("video speelt na gebruikersactie, heeft ondertitels en pauzeert bij sluiten", async ({
  page,
}) => {
  const video = page.locator("#convention-video");
  expect(
    await video.evaluate(
      (element) => element.paused && element.readyState === 0,
    ),
  ).toBe(true);
  await page.locator("[data-open-video]").click();
  await expect(page.locator("#film-dialog")).toBeVisible();
  await expect
    .poll(() => video.evaluate((element) => element.currentTime))
    .toBeGreaterThan(0);
  expect(await video.evaluate((element) => element.duration)).toBe(12);
  await expect(video.locator('track[kind="captions"]')).toHaveAttribute(
    "srclang",
    "nl",
  );
  await page.keyboard.press("Escape");
  await expect(page.locator("#film-dialog")).not.toBeVisible();
  expect(await video.evaluate((element) => element.paused)).toBe(true);
  await expect(page.locator("[data-open-video]")).toBeFocused();
});

test("een videofout kan via opnieuw proberen worden hersteld", async ({
  page,
}) => {
  await page.route("**/assets/home/sfeerimpressie.mp4", (route) =>
    route.abort(),
  );
  await page.locator("[data-open-video]").click();
  await expect(page.locator(".video-feedback")).toBeVisible();
  await expect(page.locator(".video-feedback a")).toHaveAttribute(
    "href",
    "assets/home/sfeerimpressie.mp4",
  );
  await page.unroute("**/assets/home/sfeerimpressie.mp4");
  await page.locator("[data-video-retry]").click();
  await expect
    .poll(() =>
      page
        .locator("#convention-video")
        .evaluate((element) => element.currentTime),
    )
    .toBeGreaterThan(0);
  await expect(page.locator(".video-feedback")).not.toBeVisible();
});

test("speurtocht en wedstrijd hebben eigen inhoud en werken met Escape", async ({
  page,
}) => {
  await goToSection(page, "activiteiten");
  const hunt = page.locator('[data-open-activity="hunt"]');
  await hunt.click();
  await expect(page.locator("#hunt-details")).toBeVisible();
  await expect(page.locator("#dress-details")).not.toBeVisible();
  await expect(page.locator("#hunt-details li")).toHaveCount(3);
  await expect(page.locator(".poster-original")).toHaveAttribute(
    "href",
    "images/Flyer-speurtocht.jpg",
  );
  await page.keyboard.press("Escape");
  await expect(hunt).toBeFocused();
  await page.locator('[data-open-activity="dress"]').click();
  await expect(page.locator("#dress-details")).toBeVisible();
  await expect(page.locator("#hunt-details")).not.toBeVisible();
  await expect(page.locator("#dress-details li")).toHaveCount(3);
  await expect(page.locator("#dress-details a")).toHaveAttribute(
    "href",
    "https://www.instagram.com/tcgmadness.be/",
  );
  await page.locator(".close-activity").click();
  await expect(page.locator("#activity-dialog")).not.toBeVisible();
});

test("standhouders-tabbladen en FAQ ondersteunen toetsenbordbediening", async ({
  page,
}) => {
  await goToSection(page, "standhouders");
  await expect(page.locator("#day-panel-one")).toBeVisible();
  await expect(page.locator("#day-panel-two")).not.toBeVisible();
  await page.locator("#day-one").focus();
  await page.keyboard.press("ArrowRight");
  await expect(page.locator("#day-two")).toBeFocused();
  await expect(page.locator("#day-panel-two")).toBeVisible();
  await expect(page.locator("#day-one")).toHaveAttribute("tabindex", "-1");
  await page.keyboard.press("Home");
  await expect(page.locator("#day-panel-one")).toBeVisible();
  const firstQuestion = page.locator(".faqs summary").first();
  await goToSection(page, "locatie");
  await firstQuestion.focus();
  await page.keyboard.press("Enter");
  await expect(page.locator(".faqs details").first()).toHaveAttribute(
    "open",
    "",
  );
  await page.keyboard.press("Enter");
  await expect(page.locator(".faqs details").first()).not.toHaveAttribute(
    "open",
    "",
  );
});

test("ticketbalk, modal-scrolllock en terug-naar-boven", async ({ page }) => {
  await expect(page.locator(".ticket-dock")).not.toBeVisible();
  await goToSection(page, "galerij");
  await expect(page.locator(".ticket-dock")).toBeVisible();
  const y = await page.evaluate(() => window.scrollY);
  await page.locator(".gallery-item").first().click();
  await expect(page.locator("html")).toHaveClass(/has-modal/);
  await expect(page.locator(".ticket-dock")).not.toBeVisible();
  await page.keyboard.press("Escape");
  await expect(page.locator("html")).not.toHaveClass(/has-modal/);
  expect(
    Math.abs((await page.evaluate(() => window.scrollY)) - y),
  ).toBeLessThan(3);
  await goToSection(page, "tickets");
  await expect(page.locator(".ticket-dock")).not.toBeVisible();
  await expect(page.locator(".back-to-top")).toBeVisible();
  await page.locator(".back-to-top").click();
  await expect.poll(() => page.evaluate(() => window.scrollY)).toBeLessThan(3);
  await expect(page.locator(".logo")).toBeFocused();
});

test("geen horizontale overflow op kleine, middelgrote en grote schermen", async ({
  page,
}) => {
  for (const width of [320, 390, 768, 820, 1024, 1440]) {
    await page.setViewportSize({ width, height: 900 });
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= window.innerWidth,
      ),
    ).toBe(true);
  }
});

test("WCAG A/AA-controle van de pagina en fotoweergave", async ({ page }) => {
  const scan = () =>
    new AxeBuilder({ page })
      .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
      .analyze();
  const initial = await scan();
  expect(
    initial.violations.map(({ id, nodes }) => ({
      id,
      targets: nodes.map((node) => node.target),
    })),
  ).toEqual([]);
  await openPhoto(page);
  const modal = await scan();
  expect(
    modal.violations.map(({ id, nodes }) => ({
      id,
      targets: nodes.map((node) => node.target),
    })),
  ).toEqual([]);
});

test("belangrijkste links en inhoud blijven zonder JavaScript bruikbaar", async ({
  browser,
  page,
}) => {
  const context = await browser.newContext({
    javaScriptEnabled: false,
    viewport: page.viewportSize(),
  });
  const fallback = await context.newPage();
  await fallback.goto("http://127.0.0.1:4173/index.html");
  await expect(fallback.locator("html")).toHaveClass("no-js");
  await expect(fallback.locator("#navigation")).toBeVisible();
  await expect(fallback.locator(".menu-toggle")).not.toBeVisible();
  await expect(fallback.locator(".gallery-filters")).not.toBeVisible();
  await expect(fallback.locator(".gallery-item").first()).toHaveAttribute(
    "href",
    "images/about/tcg-madness-01.jpg",
  );
  await expect(fallback.locator("[data-open-video]")).toHaveAttribute(
    "href",
    "assets/home/sfeerimpressie.mp4",
  );
  await expect(fallback.locator('[data-open-activity="hunt"]')).toHaveAttribute(
    "href",
    "images/Flyer-speurtocht.jpg",
  );
  await expect(fallback.locator("#day-panel-one")).toBeVisible();
  await expect(fallback.locator("#day-panel-two")).toBeVisible();
  await expect(
    fallback.locator('[data-ticket-placement="day"]'),
  ).toHaveAttribute("href", checkout);
  await context.close();
});

test("vensters hebben ook zonder native dialog-API een afgeschermde achtergrond", async ({
  page,
}) => {
  await page.addInitScript(() => {
    HTMLDialogElement.prototype.showModal = undefined;
    HTMLDialogElement.prototype.close = undefined;
  });
  await page.reload();
  await expect(page.locator("html")).toHaveClass(/is-enhanced/);
  await openPhoto(page);
  await expect(page.locator("#gallery-dialog")).toHaveClass(/dialog-fallback/);
  await expect(page.locator(".dialog-backdrop")).toBeVisible();
  expect(await page.locator("main").evaluate((element) => element.inert)).toBe(
    true,
  );
  await page.keyboard.press("Shift+Tab");
  await expect(page.locator("#photo-original")).toBeFocused();
  await page.mouse.click(2, 2);
  await expect(page.locator("#gallery-dialog")).not.toBeVisible();
  await expect(page.locator(".dialog-backdrop")).not.toBeVisible();
  expect(await page.locator("main").evaluate((element) => element.inert)).toBe(
    false,
  );
  await expect(page.locator(".gallery-item").first()).toBeFocused();
});
